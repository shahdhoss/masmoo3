const { MongoClient } = require('mongodb');

const uri = 'mongodb://127.0.0.1:27017'; // Replace with your MongoDB connection string
const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');

    const database = client.db('my_database');
    const users = database.collection('users');

    // Insert a document
    await users.insertOne({ name: 'Alice', age: 25 });

    // Find and display all documents
    const allUsers = await users.find().toArray();
    console.log(allUsers);
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
