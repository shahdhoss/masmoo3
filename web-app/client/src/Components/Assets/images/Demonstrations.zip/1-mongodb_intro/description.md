# MongoDB Basics with Node.js

In this tutorial, we will learn the **basics of MongoDB**, a popular **NoSQL database**. MongoDB stores data in **JSON-like documents**, making it flexible and easy to use for modern applications.

---

## Steps:

1. **Install MongoDB** – Set up MongoDB on your system.
2. **Start the MongoDB Server** – Run MongoDB locally.
3. **Use the MongoDB Shell** – Perform basic database operations.

---

## Installation

### **For Windows:**

Download and install MongoDB from the [official website](https://www.mongodb.com/try/download/community).

### **For macOS (using Homebrew):**

```bash
brew tap mongodb/brew
brew install mongodb-community@7.0
```

### **For Linux (Ubuntu):**

```bash
sudo apt update
sudo apt install -y mongodb
```

---

## Starting the MongoDB Server

Once installed, start the MongoDB service:

```bash
# Start MongoDB (Windows)
mongod

# Start MongoDB (macOS & Linux)
brew services start mongodb-community@7.0
sudo systemctl start mongod
```

To check if MongoDB is running, open a new terminal and type:

```bash
mongo
```

---

## Basic MongoDB Commands

Once inside the MongoDB shell, you can execute the following commands:

### **1. Show all databases:**

```bash
show dbs
```

### **2. Create or switch to a database:**

```bash
use my_database
```

### **3. Show all collections in a database:**

```bash
show collections
```

### **4. Insert a document into a collection:**

```bash
db.users.insertOne({ name: "Alice", age: 25, city: "New York" })
```

### **5. Insert multiple documents:**

```bash
db.users.insertMany([
  { name: "Bob", age: 30, city: "Los Angeles" },
  { name: "Charlie", age: 35, city: "Chicago" }
])
```

### **6. Retrieve all documents from a collection:**

```bash
db.users.find()
```

### **7. Find a document with a filter:**

```bash
db.users.findOne({ name: "Alice" })
```

### **8. Update a document:**

```bash
db.users.updateOne({ name: "Alice" }, { $set: { age: 26 } })
```

### **9. Delete a document:**

```bash
db.users.deleteOne({ name: "Charlie" })
```

### **10. Drop a collection:**

```bash
db.users.drop()
```

---

## Running MongoDB with Node.js

To use MongoDB in a **Node.js application**, install the MongoDB driver:

```bash
npm install mongodb
```

Then, connect to MongoDB in your Node.js file (`server.js`):

```javascript
const { MongoClient } = require('mongodb');

const uri = 'mongodb://127.0.0.1:27017'; // Replace with your MongoDB connection string
const client = new MongoClient(uri);

async function run() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');

    const database = client.db('my_database');
    const users = database.collection('users');

    // Insert a document
    await users.insertOne({ name: 'Alice', age: 25 });

    // Find and display all documents
    const allUsers = await users.find().toArray();
    console.log(allUsers);
  } finally {
    await client.close();
  }
}

run().catch(console.dir);
```

---
